
#include "uart.h"
#define GPA1CON  (*(volatile unsigned int * )0x11400020 )
#define GPA1PUD  (*(volatile unsigned int * )0x11400028 )
#define CLK_SRC_PERIL0  (*(volatile unsigned int * )0x1003C250 )
#define CLK_DIV_PERIL0  (*(volatile unsigned int * )0x1003C550 )
void mydelay_ms(int time)  
{  
    int i, j;  
    while(time--)  
    {  
        for (i = 0; i < 5; i++)  
            for (j = 0; j < 514; j++);  
    }  
} 
int strcmp(const char *src, const char *des)
{
    while(*src || *des)
    {
        if(*src > *des)  
            return 1;  
        else if(*src < *des)  
            return 2;  
        else  
        {  
            src++;  
            des++;  
        }  
    }
    return 0;
}
void uart2_init(void)
{
    GPA1CON = (GPA1CON & ~0xFF ) | (0x22); //GPA1_0:RX;GPA1_1:TX  
    CLK_SRC_PERIL0 = ((0 << 24) | (0 << 20) | (6 << 16) | (6 << 12) | (6<< 8) | (6 << 4) | (6));
    CLK_DIV_PERIL0 = ((7 << 20) | (7 << 16) | (7 << 12) | (7 << 8) | (7 << 4) | (7));    

    UART2.ULCON2 = (UART2.ULCON2 & (~(0x3 << 0))) | (0x3 << 0); //Normal mode, No parity,One stop bit,8 data bits  
    UART2.UCON2 = (UART2.UCON2 & (~(0x5 << 0))) | (0x5 << 0);  //Interrupt request or polling mode  
    //Baud-rate : src_clock:100Mhz  
    UART2.UBRDIV2 = 53;  
    UART2.UFRACVAL2 = 0x4; 
}
void putc0(const char data)  
{  
    while(!(UART2.UTRSTAT2 & (0x1 << 2)));  
    UART2.UTXH2 = data;  
    if (data == '\n')  
            putc0('\r');  
}
char getc0(void)  
{  
    char data;  
    while(!(UART2.UTRSTAT2 & (0x1 << 0)));  //1,2
    data = UART2.URXH2;  
    if ((data == '\n') || (data == '\r'))  
    {  
        putc0('\n');  
        putc0('\r');  
    }  
    else  
        putc0(data);  
  
    return data;  
}  
void puts0(const  char  *pstr)  
{  
    while(*pstr != '\0')  
        putc0(*pstr++);  
} 
void gets0(char *p)  
{  
    char data;  
    while((data = getc0())!= '\r')  
        *p++ = data;  
    if(data == '\r')  
        *p++ = '\r';  
    *p = '\0';  
}


