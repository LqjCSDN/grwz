

void MMA_init(void);


