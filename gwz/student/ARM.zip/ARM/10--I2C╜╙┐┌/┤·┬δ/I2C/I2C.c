#include "uart.h"
#define GPBCON    (*(volatile unsigned int *)0x11400040)
#define GPBDAT    (*(volatile unsigned int *)0x11400044)
#define GPBPUD    (*(volatile unsigned int *)0x11400048)
#define GPX3CON    (*(volatile unsigned int *)0x11000C60)
#define GPX3DAT    (*(volatile unsigned int *)0x11000C64)
#define GPX3PUD    (*(volatile unsigned int *)0x11000C68)
#define I2CCON5    (*(volatile unsigned int *)0x138B0000)
#define I2CSTAT5    (*(volatile unsigned int *)0x138B0004)
#define I2CADD5    (*(volatile unsigned int *)0x138B0008)
#define I2CDS5    (*(volatile unsigned int *)0x138B000C)
#define I2CLC5    (*(volatile unsigned int *)0x138B0010)
#define MMA_XOUT   0x00
#define MMA_YOUT   0x01
#define MMA_ZOUT   0x02
#define MMA_TILT   0x03
#define MMA_SRST   0x04
#define MMA_SPCNT  0x05
#define MMA_INTSU  0x06
#define MMA_MODE   0x07
#define MMA_SR     0x08
#define MMA_PDET   0x09
#define MMA_PD     0x0A
void iic_read(unsigned char slave_addr, unsigned char addr, unsigned char *data) 
{    
    I2CDS5 = slave_addr; //将从机地址写入I2CDS寄存器中    
    I2CCON5 = (1 << 7)|(1 << 6)|(1 << 5); //设置时钟并使能中断    
    I2CSTAT5 = 0xf0; //[7:6]设置为0b11，主机发送模式；     
    while(!(I2CCON5 & (1 << 4))); // 等待传输结束，传输结束后，I2CCON [4]位为1，标识有中断发生；       
    I2CDS5 = addr; //写命令值    
    I2CCON5 = I2CCON5 & (~(1 << 4)); // I2CCON [4]位清0，继续传输    
    while(!(I2CCON5 & (1 << 4)));    // 等待传输结束    
    I2CSTAT5 = 0xD0; // I2CSTAT[5:4]位写0b01,发出停止信号    
    
    I2CDS5 = slave_addr | 1; //表示要读出数据    
    I2CCON5 = (1 << 7)|(1 << 6) |(1 << 5) ; //设置时钟并使能中断    
    I2CSTAT5 = 0xb0; //[7:6]位0b10,主机接收模式；       
    while(!(I2CCON5 & (1 << 4))); //等待传输结束，接收数据    
    I2CCON5 &= ~((1<<7)|(1 << 4)); // I2CCON [4]位清0，继续传输，接收数据，     
    while(!(I2CCON5 & (1 << 4)));  // 等待传输结束   
    *data = I2CDS5;  
    I2CSTAT5 = 0x90;  
    I2CCON5 &= ~(1<<4);       /*clean interrupt pending bit  */  
} 
void iic_write (unsigned char slave_addr, unsigned char addr, unsigned char data)
{
    
    I2CCON5 = (1 << 7)|(1 << 6)|(1 << 5) ;
    I2CSTAT5 |= 0x1<<4;  

    I2CDS5 = slave_addr;
    I2CSTAT5 = 0xf0;  
    while(!(I2CCON5 & (1 << 4))); 

    I2CDS5 = addr;
    I2CCON5 = I2CCON5 & (~(1 << 4));
    while(!(I2CCON5 & (1 << 4)));

    I2CDS5 = data;
    I2CCON5 = I2CCON5 & (~(1 << 4));
    while(!(I2CCON5 & (1 << 4)));

    I2CSTAT5 = 0xd0;
    I2CCON5 = I2CCON5 & (~(1 << 4));
    mydelay_ms(1000);
}
void  MMA_init()
{
    puts0("start MMA_MODE init\n\r");
    iic_write(0x98, MMA_MODE, 0x00); 
    puts0("start MMA_SPCNT init\n\r"); 
    iic_write(0x98, MMA_SPCNT, 0x00);
    puts0("start MMA_INTSU init\n\r");  
    iic_write(0x98, MMA_INTSU, 0x00);
    puts0("start MMA_PDET init\n\r");  
    iic_write(0x98, MMA_PDET, 0x75); 
    puts0("start MMA_SR init\n\r"); 
    iic_write(0x98, MMA_SR, 0x00);
    puts0("start MMA_PD init\n\r");
    iic_write(0x98, MMA_PD, 0x17);
    puts0("start MMA_MODE init\n\r");
    iic_write(0x98, MMA_MODE, 0x01); 
}
void hex_to_ascii(unsigned char *dst, unsigned char src)
{
    unsigned char temp = src >> 4;
    if(temp <= 0x09)
        *dst++ = temp + '0';
    else
        *dst++ = temp - 0x0a + 'A';
    
    temp = src & 0x0f;
    if(temp <= 0x09)
        *dst++ = temp + '0';
    else
        *dst++ = temp - 0x0a + 'A';
}
int main(void)
{
	unsigned char x, y, z;
	unsigned char buffer[7];
	GPBCON = (GPBCON & ~(0xF<<12)) | 0x3<<12;
	GPBCON = (GPBCON & ~(0xF<<8)) | 0x3<<8;
	mydelay_ms(100);
	uart2_init();
	puts0("start MMA init\n");
	I2CSTAT5 = 0xD0;  
        I2CCON5 &= ~(1<<4);    
	mydelay_ms(100);
	MMA_init();
	puts0("MMA init finish\n");
	mydelay_ms(100);
	while(1)
	{
		puts0("X,Y,Z:");
		iic_read(0x99, MMA_XOUT, &x);
		hex_to_ascii(&buffer[0], (x&0xff));
    		iic_read(0x99, MMA_YOUT, &y);
		hex_to_ascii(&buffer[2], (x&0xff));
		iic_read(0x99, MMA_ZOUT, &z);
		hex_to_ascii(&buffer[4], (x&0xff));
		buffer[6] = '\n';;
                puts0(buffer);
		mydelay_ms(2000);
	}
	return 0;
}

