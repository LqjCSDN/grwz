/* UART2*/  
typedef struct {  
                unsigned int ULCON2;  
                unsigned int UCON2;  
                unsigned int UFCON2;  
                unsigned int UMCON2;  
                unsigned int UTRSTAT2;  
                unsigned int UERSTAT2;  
                unsigned int UFSTAT2;  
                unsigned int UMSTAT2;  
                unsigned int UTXH2;  
                unsigned int URXH2;  
                unsigned int UBRDIV2;  
                unsigned int UFRACVAL2;  
                unsigned int UINTP2;  
                unsigned int UINTSP2;  
                unsigned int UINTM2;  
}uart2;  
#define UART2 ( * (volatile uart2 *)0x13820000 ) 

void uart2_init(void);
void putc0(const char data);
char getc0(void);
void puts0(const char *pstr);
void gets0(char *p);
void mydelay_ms(int time);
